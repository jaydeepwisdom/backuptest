( function($){
	$( document ).ready(function (){
		$( '.zita-typography-select' ).zitaSelect();
	} );
} )( jQuery );