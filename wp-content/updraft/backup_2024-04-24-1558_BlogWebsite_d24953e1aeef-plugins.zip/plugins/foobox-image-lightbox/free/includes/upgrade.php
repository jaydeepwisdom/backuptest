<div id="foobox-free-upgrade">
	<ul class="foobox_features">
		<li>Social sharing</li>
		<li>Video support</li>
		<li>HTML support</li>
		<li>iFrame support</li>
		<li>Deeplinking</li>
		<li>Fullscreen mode</li>
		<li>Built-in slideshow</li>
		<li>Metro lightbox style</li>
		<li><strong>4</strong> more color schemes</li>
		<li><strong>11</strong> more button icons</li>
		<li><strong>10</strong> more loader icons</li>
	</ul>

	<p>Out of the box support for the following galleries and plugins...</p>
	<ul class="foobox_features tick2">
		<li>FooGallery</li>
		<li>Justified Image Grid</li>
		<li>JetPack Tiled Gallery</li>
		<li>NextGen</li>
		<li>WooCommerce product images</li>
		<li>Envira Gallery</li>
	</ul>

	<p>And also don't forget...</p>
	<ul class="foobox_features single_column tick3">
		<li>FooBox is actively developed and updated regularly</li>
		<li>Fast and friendly premium support</li>
		<li>A license to suit your budget</li>
		<li>85+ settings to customize to your heart's content</li>
	</ul>
</div>