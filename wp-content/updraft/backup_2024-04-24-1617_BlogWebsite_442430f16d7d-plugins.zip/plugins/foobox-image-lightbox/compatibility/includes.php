<?php

require_once FOOBOX_BASE_PATH . 'compatibility/class-elementor.php';
require_once FOOBOX_BASE_PATH . 'compatibility/class-envira.php';
require_once FOOBOX_BASE_PATH . 'compatibility/class-wprocket.php';

new foobox_compatibilty_elementor();
new foobox_compatibilty_envira();
new foobox_compatibilty_wprocket();
